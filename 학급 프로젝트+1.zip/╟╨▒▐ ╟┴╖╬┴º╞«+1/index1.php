<?php include "getDB.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>학급프로젝트</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
  <div id="board_area"> 
  <h1>학급게시판</h1>
  <img src="https://www.munsan-gco.hs.kr/images/logo.png" alt="">
  <div id="main">문산수억고 2학년 9반 학급게시판</div>
    <table class="list-table">
      <thead>
          <tr>
              <th width="70">번호</th>
                <th width="500">제목</th>
                <th width="120">글쓴이</th>
                <th width="100">작성일</th>
                <th width="100">조회수</th>
            </tr>
        </thead>
        <?php
        // board테이블에서 idx를 기준으로 내림차순해서 5개까지 표시
          $sql = mq("select * from board order by idx desc limit 0,5"); 
            while($board = $sql->fetch_array())
            {
              //title변수에 DB에서 가져온 title을 선택
              $title=$board["title"]; 
              if(strlen($title)>30)
              { 
                //title이 30을 넘어서면 ...표시
                $title=str_replace($board["title"],mb_substr($board["title"],0,30,"utf-8")."...",$board["title"]);
              }
        ?>
      <tbody>
        <tr>
          <td width="70"><?php echo $board['idx']; ?></td>
          <td width="500"><a href=""><?php echo $title;?></a></td>
          <td width="120"><?php echo $board['name']?></td>
          <td width="100"><?php echo $board['date']?></td>
          <td width="100"><?php echo $board['hit']; ?></td>
        </tr>
      </tbody>
      <?php } ?>
    </table>
    <div id="write_btn">
      <a href="/page/board/write.php"><button>글쓰기</button></a>
    </div>
  </div>
  <div id="Tel">
    TEL. 031-952-2402 (행정실: 031-952-2666, 031-953-2403)<br>
    FAX. 031-952-2403(교무실), 031-953-2307(행정실)
    </div>
</body>
</html>


아래 써져있는 글은 mysql 연결 참고용 코드들
<?php
require_once('MysqliDb.php'); //DB에 연결한다.
$db = new MysqliDb('localhost', 'root', 'dlacogjsqkqh!#@', 'notice_board'); //notice_board에 접속한다.
$data = Array ("넣고자하는 DB 테이블 이름" => "데이터"); //해당 테이블에 해당 데이터를 삽입할 $data를 지정해준다.
$id = $db->insert ('notice_data', $data); //위 데이터를 기반하여 실제 데이터를 삽입한다.
if($id)
    echo "<scripts>alert('게시글이 성공적으로 저장되었습니다.')"; //id가 만약에 있다 -> 성공적으로 저장됨
else
    echo "<scripts>alert('게시글 저장에 실패하였습니다.')"; //아니다 없다 -> 실패
?>

DB 테이블 이름
idx -> 글 쓴 번호를 1~ 순차적으로 올라가짐(알아서 올라감)
Name -> 글쓴이 저장하는 곳
Pw -> 글 수정 시 필요한 패스워드 저장하는 곳
Title -> 글의 제목 저장하는 곳
Content -> 글 내용 저장하는 곳
Data -> 날짜 (아마 ("Data" => "(Y-m-d)"))로 하면 해당 날짜 저장될거임.
hit -> 조회수
